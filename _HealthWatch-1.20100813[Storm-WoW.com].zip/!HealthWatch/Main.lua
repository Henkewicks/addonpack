local _,HealthWatch=...
local Frame=CreateFrame("ScrollingMessageFrame","!HealthWatch",UIParent)	
Frame.Threshold=35
Frame.Warned=false
-- Initialize
function HealthWatch:Initialize()	
	Frame:SetWidth(450)
	Frame:SetHeight(200)
	Frame:SetPoint("CENTER",UIParent,"CENTER",0,0)	
	Frame:SetFont("Interface\\AddOns\\!HealthWatch\\Res\\RESEGRG_.TTF",30,"THICKOUTLINE")
	Frame:SetShadowColor(0.00,0.00,0.00,0.75)
	Frame:SetShadowOffset(3.00,-3.00)
	Frame:SetJustifyH("CENTER")		
	Frame:SetMaxLines(2)
	Frame:SetInsertMode("BOTTOM")
	Frame:SetTimeVisible(1)
	Frame:SetFadeDuration(1)		
	HealthWatch:Update()
end
-- Update health warning
function HealthWatch:Update()	
	if(floor((UnitHealth("player")/UnitHealthMax("player"))*100)<=Frame.Threshold and Frame.Warned==false)then
		PlaySoundFile("Interface\\AddOns\\!HealthWatch\\Res\\Warning.wav")	
		Frame:AddMessage("- LOW HEALTH -", 1, 0, 0, nil, 3)
		Frame.Warned=true
		return
	end
	if(floor((UnitHealth("player")/UnitHealthMax("player"))*100)>Frame.Threshold)then
		Frame.Warned=false
		return
	end	
end
-- Handle events
function HealthWatch:OnEvent(Event,Arg1,...)
	if(Event=="PLAYER_LOGIN")then
		HealthWatch:Initialize()
		return
	end	
	if(Event=="UNIT_HEALTH" and Arg1=="player")then
		HealthWatch:Update()
		return
	end	
end
Frame:SetScript("OnEvent",HealthWatch.OnEvent)
Frame:RegisterEvent("PLAYER_LOGIN")
Frame:RegisterEvent("UNIT_HEALTH")