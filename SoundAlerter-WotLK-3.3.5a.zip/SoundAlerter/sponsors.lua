SA_sponsors = {
	["A"] = "Official Developer of SoundAlerter",
	["B"] = "Official Sponsor of SoundAlerter",
	["C"] = "Official Contributor of SoundAlerter",
--devs
	["Trolollolol"] = { ["Realm"] = "Ragnaros", ["Type"] = "A" },
	["Trollolloll"] = { ["Realm"] = "Ragnaros", ["Type"] = "A" },
	["Trollololol"] = { ["Realm"] = "Ragnaros", ["Type"] = "A" },
	["Trollollolol"] = { ["Realm"] = "Ragnaros", ["Type"] = "A" },
	["Trollolollo"] = { ["Realm"] = "Deathwing", ["Type"] = "A" },
	["Trolollollol"] = { ["Realm"] = "Deathwing", ["Type"] = "A" },
	["Trolollolol"] = { ["Realm"] = "Blackrock [PvP only]", ["Type"] = "A" },
--sponsors
--contributors
--[[IMPORTANT: Removed Frostwolf, Neltharion and Warsong contributers as they are upgrading to Cataclysm
				if you want you name added back to list on another realm, PM me on the forums]]
	--Deathwing
	["Buttercocoa"] = { ["Realm"] = "Ragnaros", ["Type"] = "C" },
	["Jeuriess"] = { ["Realm"] = "Deathwing", ["Type"] = "C" },
	["Sanathas"] = { ["Realm"] = "Deathwing", ["Type"] = "C" },
	["Natasi"] = { ["Realm"] = "Ragnaros", ["Type"] = "C" },
	["Aloysius"] = { ["Realm"] = "Ragnaros", ["Type"] = "C" },
	["Sanathas"] = { ["Realm"] = "Ragnaros", ["Type"] = "C" },
	["Kayrop"] = { ["Realm"] = "Ragnaros", ["Type"] = "C" }
	}
